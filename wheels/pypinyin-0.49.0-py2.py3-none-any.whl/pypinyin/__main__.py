#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pypinyin.runner import main

if __name__ == '__main__':
    main()
