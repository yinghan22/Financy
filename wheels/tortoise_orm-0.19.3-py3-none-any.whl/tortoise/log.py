import logging

logger = logging.getLogger("tortoise")
db_client_logger = logging.getLogger("tortoise.db_client")
