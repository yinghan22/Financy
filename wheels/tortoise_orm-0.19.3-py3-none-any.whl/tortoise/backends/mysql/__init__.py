from .client import MySQLClient

client_class = MySQLClient
