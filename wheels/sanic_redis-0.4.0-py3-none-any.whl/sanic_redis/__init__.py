"""
Sanic-Redis init file
"""
from .core import SanicRedis, __version__ as version

__version__ = version
__all__ = ['SanicRedis']

